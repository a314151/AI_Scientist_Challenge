# Literature Review API

This is a literature review service that implements the `/literature_review` endpoint for the AI Scientist Challenge. It uses an integrated workflow to retrieve relevant papers from multiple sources and generate comprehensive literature reviews.

## Features

- **Literature Review** (`/literature_review`): Conducts comprehensive literature reviews using retrieval-augmented generation
  - Multi-source paper retrieval (arXiv, OpenAlex, CrossRef, OpenReview)
  - LLM-based paper reranking
  - Two-stage generation: plan generation + review writing
  - Automatic citation formatting and normalization
  - Streaming responses in Server-Sent Events (SSE) format

## Models Used

- **deepseek-chat**: Standard LLM for literature review generation
- **text-embedding-v4**: Embedding model for semantic similarity (if configured)

## Setup

1. Create a `.env` file in the project root and fill in your API credentials:
   ```
   # Base URL for the model API endpoint
   SCI_MODEL_BASE_URL=https://api.deepseek.com

   # API key for authentication
   SCI_MODEL_API_KEY=your-api-key-here

   # Standard LLM model
   SCI_LLM_MODEL=deepseek-chat

   # Configuration for literature review
   SCI_N_CANDIDATES=50
   SCI_N_KEYWORDS=3
   SCI_N_PAPERS_FOR_GENERATION=40
   SCI_MAX_TOKENS=8192
   SCI_TEMPERATURE=0.2
   SCI_SEARCH_SOURCES=arxiv,openalex

   # Optional: Port configuration
   PORT=3000
   ```

3. Build and run with Docker Compose:
   ```bash
   docker-compose up -d --build
   ```

4. The service will be available at `http://localhost:3000`

## API Endpoints

### Literature Review

**Endpoint:** `POST /literature_review`

**Request:**
```json
{
  "query": "What are the latest advances in transformer models?"
}
```

**Response:** Streaming SSE format
```
data: {"type":"status","message":"Searching for relevant papers..."}
data: {"type":"status","message":"Found 50 papers. Generating review..."}
data: {"type":"status","message":"Generating review plan..."}
data: {"type":"status","message":"Plan generated. Writing review..."}
data: {"object":"chat.completion.chunk","choices":[{"delta":{"content":"## Recent"}}]}
data: {"object":"chat.completion.chunk","choices":[{"delta":{"content":" Advances"}}]}
...
data: [DONE]
```

### Health Check

**Endpoint:** `GET /health`

**Response:**
```json
{
  "status": "ok"
}
```

## Error Handling

All endpoints return standard HTTP status codes with JSON response bodies for error scenarios:

- **400 Bad Request**: Missing required parameters
  ```json
  {
    "error": "Bad Request",
    "message": "Query is required"
  }
  ```

- **500 Internal Server Error**: Server-side errors
  ```json
  {
    "error": "Internal Server Error",
    "message": "Error description"
  }
  ```

**Note:** For streaming endpoints, errors that occur during streaming will interrupt the stream. All validation errors are caught before streaming begins and returned as HTTP status code + JSON format.

## Development

### Local Development

1. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```

2. Run the application:
   ```bash
   python app.py
   ```

### Testing

You can test the endpoints using curl or any HTTP client:

```bash
# Literature Review
curl -X POST http://localhost:3000/literature_review \
  -H "Content-Type: application/json" \
  -d '{"query": "What are transformers in NLP?"}'
```

## Configuration

The service supports the following environment variables:

- `SCI_MODEL_BASE_URL`: Base URL for the model API endpoint (default: `https://api.deepseek.com`)
- `SCI_MODEL_API_KEY`: API key for authentication (required)
- `SCI_LLM_MODEL`: LLM model name (default: `deepseek-chat`)
- `SCI_N_CANDIDATES`: Number of candidate papers to retrieve (default: `50`)
- `SCI_N_KEYWORDS`: Number of keywords for search query generation (default: `3`)
- `SCI_N_PAPERS_FOR_GENERATION`: Number of papers to use for review generation (default: `40`)
- `SCI_MAX_TOKENS`: Maximum tokens for generation (default: `8192`)
- `SCI_TEMPERATURE`: Temperature for LLM generation (default: `0.2`)
- `SCI_SEARCH_SOURCES`: Comma-separated list of search sources (default: `arxiv,openalex`)
  - Available sources: `arxiv`, `openalex`, `crossref`, `openreview`
- `PORT`: Server port (default: `3000`)

## Technology Stack

- **FastAPI**: Modern async web framework
- **Integrated Workflow**: Custom retrieval and generation pipeline
- **arXiv API**: Paper retrieval from arXiv
- **OpenAlex API**: Paper retrieval from OpenAlex
- **Uvicorn**: ASGI server
- **Docker**: Containerization

## Workflow

The literature review generation follows this workflow:

1. **Query Parsing**: Parse user query to extract core topic, keywords, time constraints, and special requirements
2. **Paper Retrieval**: Search multiple sources (arXiv, OpenAlex, etc.) for relevant papers
3. **Paper Selection**: Select top N papers based on relevance
4. **Plan Generation**: Generate a structured plan for the literature review
5. **Review Generation**: Generate the complete literature review following the plan
6. **Citation Normalization**: Normalize citations and format references
7. **Streaming Response**: Stream the review content to the client

## Notes

- All endpoints use async/await for non-blocking operations
- The service uses a two-stage generation process (plan + review) for better quality
- Citations are automatically normalized and formatted
- The service supports multiple paper sources for comprehensive retrieval
- Token usage is logged to `token_use.log` for monitoring
